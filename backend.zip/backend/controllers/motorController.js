const db = require("../db");

exports.getMotorStatus = (req, res) => {
  db.query("SELECT pump_status FROM sensor_data ORDER BY timestamp DESC LIMIT 1", (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ status: results[0].pump_status });
  });
};
