// controllers/sensorController.js

const db = require("../db");

exports.getSensorData = (req, res) => {
  db.query("SELECT * FROM sensor_data ORDER BY timestamp DESC", (err, results) => {
  if (err) return res.status(500).json({ error: err.message });
  res.json(results); // ← returns an array of all rows
});
};
