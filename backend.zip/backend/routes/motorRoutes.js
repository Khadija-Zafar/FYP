const express = require("express");
const router = express.Router();
const { getMotorStatus } = require("../controllers/motorController");

router.get("/", getMotorStatus);
module.exports = router;
